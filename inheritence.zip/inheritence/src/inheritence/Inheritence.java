/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author macstudent
 */
public class Inheritence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
   
      partTime pt = new partTime(1,"jaspreet",4,25);  
        System.out.print(pt.displayData());
        
        
        
        
        
       
    }
    
}
